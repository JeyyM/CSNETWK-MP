#!/usr/bin/env python3
"""
LSNP (Local Social Network Protocol) Application
"""

from src.app import main

if __name__ == "__main__":
    main()
