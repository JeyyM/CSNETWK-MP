"""Message router for handling incoming messages."""
from typing import Callable, Dict
import time, uuid
from ..network.protocol import build_message

from .ping_handler import PingHandler
from .profile_handler import ProfileHandler
from .dm_handler import DmHandler
from .post_handler import PostHandler
from .like_handler import LikeHandler
from .game_handler import GameHandler
from .group_handler import GroupHandler
from ..network.client import NetworkManager
from ..handlers.file_handler import handle_file_message

from ..core.state import app_state
from ..utils.auth import require_valid_token


class MessageRouter:
    """Routes incoming messages to appropriate handlers."""
    
    def __init__(self, network_manager: NetworkManager, verbose: bool = False):
        self.verbose = verbose
        self.network_manager = network_manager 
        
        # Initialize handlers
        self.ping_handler = PingHandler(verbose)
        self.profile_handler = ProfileHandler(verbose)
        self.dm_handler = DmHandler(network_manager, verbose)
        self.post_handler = PostHandler(verbose)
        self.like_handler = LikeHandler(verbose)
        self.game_handler = GameHandler(network_manager, verbose)
        self.group_handler = GroupHandler(network_manager, verbose)
        
        # Message type routing table
        self.handlers: Dict[str, Callable[[dict, tuple], None]] = {
            "PING": self.ping_handler.handle,
            "PROFILE": self.profile_handler.handle,
            "DM": self.dm_handler.handle,
            "POST": self.post_handler.handle,
            "LIKE": self.like_handler.handle,
            "TICTACTOE_INVITE": self.game_handler.handle_invite,
            "TICTACTOE_MOVE": self.game_handler.handle_move,
            "TICTACTOE_RESULT": self.game_handler.handle_result,
            "GROUP_CREATE": self.group_handler.handle_group_create,
            "GROUP_UPDATE": self.group_handler.handle_group_update,
            "GROUP_MESSAGE": self.group_handler.handle_group_message,
            "ACK": self._handle_ack,

            "FILE_OFFER": handle_file_message,
            "FILE_ACCEPT": handle_file_message,
            "FILE_REJECT": handle_file_message,
            "FILE_CHUNK": handle_file_message,
            "FILE_RECEIVED": handle_file_message,

            "REVOKE": self._handle_revoke,

            # Add stubs for FOLLOW and UNFOLLOW to suppress unhandled message warnings
            "FOLLOW": lambda msg, addr: None,
            "UNFOLLOW": lambda msg, addr: None,
        }
    
    def route_message(self, msg: dict, addr: tuple) -> None:
        """Route incoming messages to appropriate handlers."""
        mtype = msg.get("TYPE", "")

        # Handle ACKs immediately before any other processing
        if mtype == "ACK":
            mid = msg.get("MESSAGE_ID", "")
            if mid:
                app_state.resolve_ack(mid)
                if self.verbose:
                    print(f"ACK received for {mid} from {addr[0]}")
            return
        
        # Per-RFC auth: validate IP match + token scope/expiry/revocation per TYPE.
        # (PROFILE, PING, ACK, FILE_RECEIVED, REVOKE are allowed without tokens.)
        if not require_valid_token(msg, addr, self.verbose):
            # require_valid_token already printed a DROP reason in verbose mode
            return

        # Route to appropriate handler
        handler = self.handlers.get(mtype)
        if handler:
            handler(msg, addr)
        elif self.verbose:
            print(f"[ROUTER] Unhandled message type: {mtype}")

    def _handle_ack(self, msg: dict, addr: tuple) -> None:
        """Handle incoming ACK messages."""
        mid = msg.get("MESSAGE_ID")
        if mid:
            app_state.resolve_ack(mid)
            if self.verbose:
                print(f"[ACK] Received ACK for {mid} from {addr[0]}:{addr[1]}")
        elif self.verbose:
            print(f"[ACK] Received ACK without MESSAGE_ID from {addr[0]}:{addr[1]}")

    def _handle_revoke(self, msg: dict, addr: tuple) -> None:
        """Handle token revocation broadcast."""
        tok = msg.get("TOKEN")
        if not tok:
            if self.verbose:
                print("[REVOKE] Missing TOKEN")
            return

        parsed = app_state.parse_token(tok)
        if not parsed:
            if self.verbose:
                print("[REVOKE] Malformed token string in REVOKE")
            return

        user_id, expiry, scope = parsed

        # Mark token revoked locally and remove peer from active list
        app_state.revoke_token(tok)
        app_state.remove_peer(user_id)

        if self.verbose:
            # Print REVOKE in detailed format
            print(f"TYPE: REVOKE \nTOKEN: {tok}")

    # Convenience: used elsewhere when the local user sends a POST
    def send_post(self, user, content: str, ttl: int = 3600) -> bool:
        now = int(time.time())
        exp = now + ttl
        mid = uuid.uuid4().hex[:8]

        token = f"{user.user_id}|{exp}|broadcast"
        app_state.register_issued_token(token)  # so logout can REVOKE later

        fields = {
            "TYPE": "POST",
            "USER_ID": user.user_id,
            "CONTENT": content,
            "TTL": ttl,
            "MESSAGE_ID": mid,
            "TOKEN": token,  # scope must be 'broadcast'
        }
        msg = build_message(fields)
        return self.network_manager.send_broadcast(msg)
